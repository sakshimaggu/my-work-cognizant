angular.module('game',[]);
angular.module('game').
 controller('gameCtrl',ctrl);
	
function ctrl($scope){
		var count = 0;
			$scope.cards = [
		{
			flipped: false,
			img:'images/8-ball.png',
		},
		{
			flipped: false,
			img:'images/8-ball.png',
		},
		{
			flipped: false,
			img:'images/baked-potato.png',
		},
		{
			flipped: false,
			img:'images/baked-potato.png',
		},
		{
			flipped: false,
			img:'images/dinosaur.png',
		},
		{
			flipped: false,
			img:'images/dinosaur.png',
		},
		{
			flipped: false,
			img:'images/kronos.png',
		},
		{
			flipped: false,
			img:'images/kronos.png',
		},
		{
			flipped: false,
			img:'images/rocket.png',
		},
		{
			flipped: false,
			img:'images/rocket.png',
		},
		{
			flipped: false,
			img:'images/skinny-unicorn.png',
		},
		{
			flipped: false,
			img:'images/skinny-unicorn.png',
		},
		{
			flipped: false,
			img:'images/that-guy.png',
		},
		{
			flipped: false,
			img:'images/that-guy.png',
		},
		{
			flipped: false,
			img:'images/zeppelin.png',
		},
		{
			flipped: false,
			img:'images/zeppelin.png',
		}
	];

		 var shuffle = function(o){ 
        for(var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
        return o;
        };
 
          $scope.cards = shuffle($scope.cards);
       // console.log($scope.cards);

         var flag=0;
         $scope.IsVisible = false;
         
         // $scope.flip =function(item){
         // 	this.flipped = !this.flipped;
         // }
         var checkFliped  = function(item){
        			var img1;
        			if(count ==1) {
        				img1 = item.img;
        				return true;
        			}
        			if(count ==2){
        				if(img1 === item.img)
        					return true;
        				else{
        					count =0;
        					return false;
        				}
        			}
        			
        		};	
        $scope.myFunc = function(index, item) {
        	    //console.log(event.currentTarget);
        	    item.flipped = true;
        		$("#backImg"+index).hide();
        		$("#cardImg"+index).show();
        		
        		count++;
        	 // $scope.flip(item);
        	 	var x = checkFliped(item);
        	 	if(!x) {
	        	 		item.flipped =!item.flipped;
        	 	}

        		console.log(item.flipped);
       };
   
         //        flag++;
         // 	    var a= item.img;
        	//     console.log(index,item);
        	//     flip=function(){
        	//     	if(flag==1)
        	//     }
                     	// 	var b=item.img;
         //        console.log(b);
         //         if(a===b){
         // 	      alert('hi');
         // }

 
        
         // console.log($scope.cards);

       // $scope.IsVisible = false;
        //     $scope.myFunc = function(index) {
        // 	console.log(index);
        // 	 for(var i=0;i<index;i++){
        //          $scope.IsVisible = $scope.IsVisible ? false : true;
        //      }
        // };
  		
   };

