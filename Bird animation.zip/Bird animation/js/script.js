$( document ).ready(function() {
    document.getElementById("bird").style.backgroundImage="url('images/bird.png')";
		var frameWidth=918;
		var frame=183; //image width
		var frames = 14;
		    var x=-183;
		    var y=0;
		   var c=0;
		function fly(){
		    c=c+1;
		    document.getElementById("bird").style.backgroundPosition = x +'px'+' '+ y + 'px';
			x=x-183;
		    if(Math.abs(x)>frameWidth)
		    {
			x = 0;
			y = y-170;
			document.getElementById("bird").style.backgroundPosition = x +'px'+' '+ y + 'px';
			} else if (c > frames) { {
				x = 0;
				y = 0;
				c = 0;
			}
			}		
		
	}
        setInterval(fly,60);
        var flag=true;
        var pos = 0;
        var id='';
		document.getElementById("play").onclick = function(){
		  var elem = document.getElementById("bird");
		  if(flag==true)
		  {
			  this.innerHTML='Pause';
			  id = setInterval(frame, 10);
			  function frame() {
			    if (pos == 1078) {		    
			      pos = 0;
			      } 
			    pos++;
			    elem.style.left = pos + 'px';
			  }
			  	flag=false;
		  } 
		else {
		   	this.innerHTML='Play';
		    clearInterval(id);
       	    flag=true;
        }
   }
});