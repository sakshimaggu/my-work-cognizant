  $(document).ready(function(){
   	init();

		$('.wrapper').on("click",'.switch', function(e)
		{  	
			e.preventDefault();
			$(this).parent('.generate').find('.lbl').removeClass('disabled');			
			if($(this).find("input").prop("checked") === true){
				$(this).find("input").prop("defaultChecked",null);
				$(this).parent('.generate').find('.lbl.right').addClass('disabled');
			}else{					
			    $(this).find("input").prop("defaultChecked","checked");
			    $(this).parent('.generate').find('.lbl.left').addClass('disabled');					
			}
		});
     
		function init() {
       var isChecked = '';
	     for(var i=0;i<data.info.length;i++){
            if(data.info[i].status === "On"){
            isChecked = 'checked';
        }else{
            isChecked ='';
        }
         var toggleBtn = '<div class="generate"> <p class="left lbl">'+ data.info[i].l_panel+ '</p><label class="switch"><input type="checkbox"'+ isChecked+'><div class="slider"></div></label><p class="right lbl">'
                  + data.info[i].r_panel+'</p></div>';
         $(".wrapper").append(toggleBtn); 
        };
        $('.store').on('click',function()
        {
          var fetch = $('p').not(".disabled");
          $.each(fetch,function(key,value){
                var element = $('<div>').append($(value).text());
                $('.ans_value').append(element);
           })
        });
     };
   });

//json data
  var data = {
       "info" : [
          {
          	"l_panel" : "Yes",
          	"r_panel" : "No",
          	"status" : "On"
          },
          {
          	"l_panel" : "Male",
          	"r_panel" : "Female",
          	"status" : "Off"
          },
          {
          	"l_panel" : "Show",
          	"r_panel" : "Hide",
          	"status" : "On"
          }
       ]

  }


