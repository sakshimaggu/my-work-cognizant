  $(document).ready(function(){
  	    $('.build').on('click',function()
  	    {
   			init();
        });

		$('.wrapper').on("click",'.switch', function(e)
		{  	
			e.preventDefault();
			$(this).parent('.generate').find('.lbl').removeClass('disabled');			
			if($(this).find("input").prop("checked") === true){
				$(this).find("input").prop("defaultChecked",null);
				$(this).parent('.generate').find('.lbl.right').addClass('disabled');
			}else{					
			    $(this).find("input").prop("defaultChecked","checked");
			    $(this).parent('.generate').find('.lbl.left').addClass('disabled');					
			}
		});

		function init() {
	        var x = $(".myNumber").val();
	        for(var i=0;i<x;i++){
	        /*id=btn+i*/
	        var q = '<div class="generate"> <p class="left lbl"> Show Metadata </p><label class="switch"> <input type="checkbox"> <div class="slider"></div></label> <p class="right lbl"> Show Data </p></div>';
	          	$(".wrapper").append(q);
            }
        }
   });

//json data
  var data = {
       "info" : [
          {
          	"r_panel" : "Yes",
          	"l_panel" : "No",
          	"status" : "On"
          },
          {
          	"r_panel" : "Male",
          	"l_panel" : "Female",
          	"status" : "off"
          },
          {
          	"r_panel" : "Show",
          	"l_panel" : "Hide",
          	"status" : "On"
          }
       ]

  }
console.log(data.info.length);
        //js
/*  for(var i=1;i<data.accordians.length;i++)
{
  var a  = document.createElement("div");
  var b = document.getElementById('myDiv');
  a.setAttribute('id','accTitle');
  var c=document.createElement("div");
  c.setAttribute('id','accContent');
  a.append(data.accordians[i].title);
  c.append(data.accordians[i].content);
  b.append(a);
  b.append(c);
} */  

