window.onload=function(){

var balance=1000;
var customer1={
	 cName:"John",
	 transactionStatement:[
		{
			date:new Date(),
		    amount:balance,
            money:0
		}
	]
}

var customer2={
	 cName:"Sam",
	 transactionStatement:[
		{
			date:new Date(),
		    amount:balance,
            money:0
		}
	]
}



function deposit(depositAmount,customer){
	var newBalance=depositAmount+customer.transactionStatement[customer.transactionStatement.length-1].amount;
	customer.transactionStatement.push({date:new Date() , amount:newBalance , money:depositAmount});
	/*console.log(document.getElementById("depo").value);*/
    console.log("Transacted amount:" + depositAmount);
	console.log("Your balance after deposit " + newBalance); 
	/*console.log(date);*/	
}

function withdraw(withdrawAmount,customer){
	if (customer.transactionStatement[customer.transactionStatement.length-1].amount < withdrawAmount) {
		alert("balance insufficient");
	}
	else{
		var newBalance = customer.transactionStatement[customer.transactionStatement.length-1].amount - withdrawAmount;
		customer.transactionStatement.push({date:new Date() , amount:newBalance , money:withdrawAmount});
	}
	// var amount=document.getElementById("withdraw").value;
	// newBalance=balance-parseInt(amount);
	console.log("Transacted amount:" + withdrawAmount);
	console.log("Your balance after withdrawl " + newBalance);
}

  function print(customer){
  		console.clear();
		var count=0;


		var tr = customer.transactionStatement.length>=5 ? customer.transactionStatement.length-5 : 0;

		for(i=customer.transactionStatement.length-1; i>= tr;i--)
		{
			console.log(customer.transactionStatement[i].date);
			/*console.log('hi'+i);*/
		    console.log("Transaction no:"+count);
		    console.log("Transacted amount"+customer.transactionStatement[i].money);
			console.log("Balance is:"+customer.transactionStatement[i].amount);
			count++;
        }
        
    } 	

  document.getElementById('depo').onclick = function(){
  	//console.log(customer.transactionStatement[0].amount);
  	//alert('hi');
  	var amt=parseInt(document.getElementById('val').value);
  	var customer=customer1;
    deposit(amt,customer);
  }

   document.getElementById('with').onclick = function(){
  	var amt=parseInt(document.getElementById('val').value);
  	var customer=customer1;
    withdraw(amt,customer);
  }

  document.getElementById("print").onclick = function(){
  	   var customer=customer1;
       print(customer);
  }

}