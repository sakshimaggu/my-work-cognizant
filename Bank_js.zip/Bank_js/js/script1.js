
function Customer(name,id,transactionStatement){
       var name=name;
      this.id=id;
      var transactionStatement=[{
			date:new Date(),
		    amount:1000,
            status:"",
            money:0
		}];
        this.getname=function(){
        	return name;
        }
        this.setname=function(cname){
        	name=cname;
        }
		this.gettransactionStatement=function(){
			return transactionStatement;
		}
		this.settransactionStatement=function(tr){
			transactionStatement.push(tr);
		}
}

var customer1=new Customer("John",1);
var customer2=new Customer("Sam",2);



Customer.prototype.deposit=function(depositAmount){
	    var newBalance=depositAmount+this.gettransactionStatement()[this.gettransactionStatement().length-1].amount;
		this.settransactionStatement({date:new Date() , amount:newBalance ,status:"Credit", money:depositAmount});
	    console.log("Transacted amount:" + depositAmount);
		console.log("Your balance after deposit " + newBalance); 
		console.log(this.gettransactionStatement());
		return this;
}

Customer.prototype.withdraw=function(withdrawAmount){
	    if (this.gettransactionStatement()[this.gettransactionStatement().length-1].amount < withdrawAmount) {
		alert("balance insufficient");
	    }
	else{
		var newBalance = this.gettransactionStatement()[this.gettransactionStatement().length-1].amount - withdrawAmount;
		this.settransactionStatement({date:new Date() , amount:newBalance ,status:"Debit", money:withdrawAmount});
	}
	console.log("Transacted amount:" + withdrawAmount);
	console.log("Your balance after withdrawl " + newBalance);
	return this;
}

Customer.prototype.print=function(){
	    console.clear();
		var count=1;
		var tr = this.gettransactionStatement().length>=5 ? this.gettransactionStatement().length-5 : 0;

		for(i=this.gettransactionStatement().length-1; i>= tr;i--)
		{

			var table = document.getElementById("myTable");
		    var row = table.insertRow(table.rows.length);
		    var cell1 = row.insertCell(0);
		    var cell2 = row.insertCell(1);
		    var cell3 = row.insertCell(2);
		    var cell4 = row.insertCell(3);
		    var cell5 = row.insertCell(4);
		    cell1.innerHTML = count;
		    cell2.innerHTML = this.gettransactionStatement()[i].date;
		    cell3.innerHTML = this.gettransactionStatement()[i].money;
		    cell4.innerHTML = this.gettransactionStatement()[i].status;
            cell5.innerHTML = this.gettransactionStatement()[i].amount;
			count++;
        }
}
	
  document.getElementById('depo').onclick = function(){
  	var amt=parseInt(document.getElementById('val').value);
    customer1.deposit(amt);
  }

   document.getElementById('with').onclick = function(){
  	var amt=parseInt(document.getElementById('val').value);
    customer1.withdraw(amt);
  }

  document.getElementById("print").onclick = function(){ 
       customer1.print();
  }

  console.log(customer1.deposit(100).withdraw(200));

