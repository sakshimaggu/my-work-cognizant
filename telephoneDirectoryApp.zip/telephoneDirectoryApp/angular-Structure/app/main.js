/**
 * AngularJS Tutorial 1
 * @author Nick Kaye <nick.c.kaye@gmail.com>
 */

/**
 * Main AngularJS Web Application
 */
var app = angular.module('angularWebApp', [
  'ngRoute'
]);

/**
 * Configure the Routes
 */
app.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
    // Home
    .when("/", {templateUrl: "partials/home.html"})
    // Pages
    .when("/edit", {templateUrl: "partials/edit.html", controller: "editController"})
    // else 404
    //.otherwise("/404", {templateUrl: "partials/404.html", controller: "myController"});
}]);

app.directive('myDirective', function() {
  return {
		scope: {
			myData: '='
		},
		template: '<div>Some Text From Directive and {{myData}}</div>'
  };
});

