app.controller('myController', function ($scope, $location, UserContactService) {
  console.log("Blog Controller reporting for duty.");
    
    

    var init = function(){
      $scope.directoryData = UserContactService.directory;

      $scope.user = {
        name: null,
        contact: null,
        address: null
      }
    }

    $scope.addContact = function(){
      UserContactService.addContact($scope.user, function(){
        $scope.directoryData = UserContactService.directory;

        init();
      });
    }


    $scope.editData = function(index){
      UserContactService.editData(index);
      $location.path('/edit');
    }

    $scope.clearLocal = function(){
      UserContactService.clearLocalData();
      init();
    }

     init();

});


app.controller('editController', function($scope, UserContactService, $location){

  var init = function(){
    $scope.user = UserContactService.giveMeDataToEdit();
  }

  $scope.update = function(){
    UserContactService.update($scope.user);
    $location.path('/');
  }





  init();
});
