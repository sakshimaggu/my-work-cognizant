app.factory('UserContactService', function(){
	var srv = {};

	srv.directory = [];
	srv.editIndex = null;

	var init = function(){
		srv.getDataFromLocalStorage();
		if(srv.directory == null){
			srv.directory = [];
		}
	}


	srv.getDataFromLocalStorage = function(){
		srv.directory = JSON.parse(window.localStorage.getItem("directoryAppData"));
	}

	srv.setDataToLocalStorage = function(){
		window.localStorage.setItem("directoryAppData", JSON.stringify(srv.directory) );
	}

	srv.clearLocalData = function(){
		window.localStorage.removeItem("directoryAppData");
		srv.directory = [];
	}

	
	srv.addContact = function(userObj, callbackSuccess){
		srv.directory.push(userObj);
		srv.setDataToLocalStorage();
		callbackSuccess();
	}

	srv.editData = function(index){
		srv.editIndex = index;
	}

	srv.giveMeDataToEdit = function(){
		if(srv.editIndex != null){
			return srv.directory[srv.editIndex];
		}

		return null;
	}


	srv.update = function(updateObj){
		srv.directory.splice(srv.editIndex, 1);
		srv.directory.push(updateObj);
		srv.setDataToLocalStorage();
	}

	init();


  return srv;
});