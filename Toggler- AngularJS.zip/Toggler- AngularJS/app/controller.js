  var mainApp = angular.module("toggle", []);
     	    
         mainApp.directive('toggler', function() {
            var directive = {};
            directive.restrict = 'E';
            directive.templateUrl = './template/template.html' ;
            // directive.scope = {
            //   	data : '='
            // }
            directive.controller = ['$scope',function($scope) {
                  $scope.active = function(e,x) {
                    e.preventDefault();
                    if(x.status === 'On'){
                      x.status = 'Off';
                    }
                    else{
                      x.status = 'On';
                    }
                } 
                  $scope.print = function(e,x){
                    $( "p" ).data( x.status ) === 'On';
                    //$( "p" ).data( x.status,'On' );
                    //console.log(document.getElementsByTagName('p').not(".disabled"));
                    //console.log("hi");
                    }
            }];
            return directive;
         });
         
         mainApp.controller('toggleCtrl', function($scope) { 
         	$scope.data = {
			       "info" : [
			          {
			          	"l_panel" : "Yes",
			          	"r_panel" : "No",
			          	"status" : "On"
			          },
			          {
			          	"l_panel" : "Male",
			          	"r_panel" : "Female",
			          	"status" : "Off"
			          },
			          {
			          	"l_panel" : "Show",
			          	"r_panel" : "Hide",
			          	"status" : "Off"
			          }
			         ]
              }
          });

