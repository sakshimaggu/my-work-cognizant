var app = angular.module('fullName', []);
app.controller('newCtrl', function($scope) {
    $scope.firstName = "John";
    $scope.lastName = "Doe";
});