/*var app = angular.module('edit', []);
app.controller('newCtrl', function($scope) {
    $scope.editit = "Edit me";
   
});*/

/*var app = angular.module('edit', []);
app.controller('newCtrl', ['$scope', '$window', function($scope, $window) {
      $scope.editit = 'Edit me';
      $scope.pop = function() {
      	//var html = "<div> name: {{editit}} </div>";
        //$window.alert( $scope.editit);
        $('popover-edit').modal();

      };
    }]);*/
angular.module('edit').
 controller('newCtrl',ctrl);
	
function ctrl($scope){
	
	$scope.popover = {
		text : "Edit me",
		templateUrl : 'popoverTemplate.html'
	};

		$scope.names = [
	{
		text:'50-must have plugins for extending twitter bootstrap',
		img:'images/twitter.png'
	},
	{
		text:'Making a Super Simple Registration system with PHP and MySql',
		img:'images/php.png'
	},
	{
		text:'Create a slide-out footer with this neat z-index trick',
		img:'images/z-index.png'
	},
	{
		text:'How to Make a Digital Clock with jQuery and Css3',
		img:'images/jquery.png'
	},
	{
		text:'Smooth Diagonal Fade Gallery with CSS3 Transitions',
		img:'images/css3.png'
	}
	];
}
